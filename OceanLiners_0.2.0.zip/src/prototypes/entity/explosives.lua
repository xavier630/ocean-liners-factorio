data.raw["item"]["explosives"].place_as_tile = {
    result = "water",
    condition_size = 0,
    condition = { "item-layer" }
}

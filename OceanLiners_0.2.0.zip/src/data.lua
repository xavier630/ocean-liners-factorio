--Menus now arranged in recipes.lua



--entity
require("prototypes.entity.entities")
require("prototypes.entity.sea-oil")
require("prototypes.entity.oil-rig")
require("prototypes.entity.ocean-power-pole")
require("prototypes.entity.command-tiles")

--require("prototypes.entity.explosives") enabled through config.



--items
require("prototypes.item.items")

--recipies
require("prototypes.recipe.recipes")

--tech
require("prototypes.tech.tech")

--config
require("config-impl")
